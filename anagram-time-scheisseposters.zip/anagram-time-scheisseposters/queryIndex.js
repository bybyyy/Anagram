const fs = require('fs');
let anagram = fs.readFileSync("./myIndex.txt");
const process = require('process');
let wordAsked = process.argv[2];


function binarySearch (array, x) {
	let start = 0;
	let end = array.length-1;

	while (start <= end) {
		let mid= Math.floor((start + end)/2);
		//console.log("mid: " + array[mid])

		if (x == array[mid].substr(0,x.length)) {
			result.push(array[mid]);
			anagram.splice(mid,1);
			return true;
		}

		if (array[mid] < x) {
			start = mid + 1;
	    } else {
	        end = mid - 1;
	    }
	}

	return false;
}

function swap(arr, a, b){
	let temp = arr[a];
	arr[a] = arr[b];
	arr[b] = temp;
}

function QSort(array){
	if (array.length <= 1){
		return array;
	}

	let pivot = array[array.length-1];
	let LArray = [];
	let RArray = [];
	let position = -1;

	//if the array at index i is smaller than pivot point, swap i and position +1
	for (let i = 0; i < array.length-1; i++){
		if(array[i] < pivot){
			position = position + 1;
			swap(array, i, position);
		}
	}
    position++;
	swap(array, position, array.length-1);

	//add the left and right side of the pivot to the respective array
	for (let a = 0; a < position; a++){
		LArray.push(array[a]);
	}
	for (let b = position+1; b < array.length; b++){
		RArray.push(array[b]);
	}
	//recurive, call the left and right side of the pivot
	LArray = QSort(LArray);
	RArray = QSort(RArray);
	return [...LArray, pivot, ...RArray];
}

let word = [];
let result = [];
for (var i = 0; i < wordAsked.length; i++) {
	word.push(wordAsked[i]);
}

let sortedWord = QSort(word).join('');
anagram = anagram.toString().replace(/ /g, '').split('\n');

while(binarySearch(anagram, sortedWord) == true) {
	binarySearch(anagram, sortedWord);
}
console.log(result);

